// Cloudflare Worker — proxy Printful (lecture catalogue)
// dash.cloudflare.com > Workers & Pages > Create > Hello World > Deploy > Edit code > colle ce code > Deploy
// Puis copie l'URL (https://xxx.workers.dev) dans PROXY_URL du site.
const PRINTFUL_TOKEN = "0923e31rLcOEG3OivGOg5SLUrONYkfncUUS9Iqjt";
const STORE_ID = ""; // optionnel : ID du store si le token est de niveau "compte"

export default {
  async fetch(request) {
    const cors = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    };
    if (request.method === "OPTIONS") return new Response(null, { headers: cors });
    const url = new URL(request.url);
    if (!/^\/store\/products(\/\d+)?$/.test(url.pathname))
      return new Response(JSON.stringify({ error: "Route non autorisée" }), { status: 403, headers: { ...cors, "Content-Type": "application/json" } });
    const headers = { Authorization: "Bearer " + PRINTFUL_TOKEN };
    if (STORE_ID) headers["X-PF-Store-Id"] = STORE_ID;
    const res = await fetch("https://api.printful.com" + url.pathname + url.search, { headers });
    return new Response(await res.text(), {
      status: res.status,
      headers: { ...cors, "Content-Type": "application/json", "Cache-Control": "public, max-age=300" },
    });
  },
};
